﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.ADF;
using ESRI.ArcGIS.SystemUI;
using MyMap.Forms;
using ElemeHntsHelper.Forms;

namespace ElementsHelper
{
    public sealed partial class MainForm : Form
    {
        #region class private members
        private IMapControl3 m_mapControl = null;
        private string m_mapDocumentName = string.Empty;
        private FormOverview m_FormOverview = null;
        #endregion

        #region class constructor
        public MainForm()
        {
            InitializeComponent();
        }
        #endregion

        private void MainForm_Load(object sender, EventArgs e)
        {
            //get the MapControl
            m_mapControl = (IMapControl3)axMapControl1.Object;

            //disable the Save menu (since there is no document yet)
            menuSaveDoc.Enabled = false;
        }

        #region Main Menu event handlers
        private void menuNewDoc_Click(object sender, EventArgs e)
        {
            //execute New Document command
            ICommand command = new CreateNewDocument();
            command.OnCreate(m_mapControl.Object);
            command.OnClick();
        }

        private void menuOpenDoc_Click(object sender, EventArgs e)
        {
            //execute Open Document command
            ICommand command = new ControlsOpenDocCommandClass();
            command.OnCreate(m_mapControl.Object);
            command.OnClick();
        }

        private void menuSaveDoc_Click(object sender, EventArgs e)
        {
            //execute Save Document command
            if (m_mapControl.CheckMxFile(m_mapDocumentName))
            {
                //create a new instance of a MapDocument
                IMapDocument mapDoc = new MapDocumentClass();
                mapDoc.Open(m_mapDocumentName, string.Empty);

                //Make sure that the MapDocument is not readonly
                if (mapDoc.get_IsReadOnly(m_mapDocumentName))
                {
                    MessageBox.Show("地图文件不可写！");
                    mapDoc.Close();
                    return;
                }

                //Replace its contents with the current map
                mapDoc.ReplaceContents((IMxdContents)m_mapControl.Map);

                //save the MapDocument in order to persist it
                mapDoc.Save(mapDoc.UsesRelativePaths, false);

                //close the MapDocument
                mapDoc.Close();
            }
        }

        private void menuSaveAs_Click(object sender, EventArgs e)
        {
            //execute SaveAs Document command
            ICommand command = new ControlsSaveAsDocCommandClass();
            command.OnCreate(m_mapControl.Object);
            command.OnClick();
        }

        private void menuExitApp_Click(object sender, EventArgs e)
        {
            //exit the application
            Application.Exit();
        }
        #endregion

        //listen to MapReplaced evant in order to update the statusbar and the Save menu
        //private void axMapControl1_OnMapReplaced(object sender, IMapControlEvents2_OnMapReplacedEvent e)
        //{
        //    //get the current document name from the MapControl
        //    m_mapDocumentName = m_mapControl.DocumentFilename;

        //    //if there is no MapDocument, diable the Save menu and clear the statusbar
        //    if (m_mapDocumentName == string.Empty)
        //    {
        //        menuSaveDoc.Enabled = false;
        //        statusBarXY.Text = string.Empty;
        //    }
        //    else
        //    {
        //        //enable the Save manu and write the doc name to the statusbar
        //        menuSaveDoc.Enabled = true;
        //        statusBarXY.Text = Path.GetFileName(m_mapDocumentName);
        //    }
        //}

        private void axMapControl1_OnMouseMove(object sender, IMapControlEvents2_OnMouseMoveEvent e)
        {
            statusBarXY.Text = string.Format("{0}, {1}  {2}", e.mapX.ToString("#######.##"), e.mapY.ToString("#######.##"), axMapControl1.MapUnits.ToString().Substring(4));
        }

        private void MenuItemOverview_Click(object sender, EventArgs e)
        {
            
            try
            {
                if (m_FormOverview == null || m_FormOverview.IsDisposed)
                {
                    m_FormOverview = new FormOverview(axMapControl1);
                }
                m_FormOverview.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void axTOCControl1_OnDoubleClick(object sender, ITOCControlEvents_OnDoubleClickEvent e)
        {
            esriTOCControlItem itemType  = esriTOCControlItem.esriTOCControlItemNone;
            IBasicMap basicMap = null;
            ILayer layer = null;
            object unk = null;
            object data = null;
            axTOCControl1.HitTest(e.x, e.y, ref itemType, ref basicMap, ref layer, ref unk, ref data);
            if (e.button==1)
            {
                if (itemType==esriTOCControlItem.esriTOCControlItemLegendClass)
                {
                    //取到图例
                    ILegendClass m_LengendClass = ((ILegendGroup)unk).get_Class((int)data);
                    //创建符号选择器实例
                    MyMap.Forms.SymbologyForm symbologyform= new MyMap.Forms.SymbologyForm(m_LengendClass,layer);
                    if (symbologyform.ShowDialog()==DialogResult.OK)
                    {
                        //refresh axMapControl1
                        m_mapControl.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, null, null);
                        //set the new symbology
                        m_LengendClass.Symbol = symbologyform.mySymbol;
                        //refresh axMapControl and TOCControl
                        this.axMapControl1.ActiveView.Refresh();
                        this.axTOCControl1.Refresh();
                    }
                }
            }
        }

        private void ToolStripMenuItemBookmarkManager_Click(object sender, EventArgs e)
        {
            FormBookmarkManager frm = new FormBookmarkManager(axMapControl1);
            frm.Show();
        }

        private void ToolStripMenuItemCreateBookmark_Click(object sender, EventArgs e)
        {
            FormCreateBookmark frm = new FormCreateBookmark(this);
            frm.ShowDialog();
        }

        void tempMenu_Click(object sender, EventArgs e)
        {
            ISpatialBookmark bookmark
                = (sender as ToolStripMenuItem).Tag as ISpatialBookmark;
            if (bookmark != null)
            {
                bookmark.ZoomTo(axMapControl1.Map);
                //刷新地图
                //axMapControl1.ActiveView.Refresh();
                axMapControl1.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewAll, null, axMapControl1.ActiveView.Extent);
            }
        }

        private void CloseOverviewForm()
        {
            if (m_FormOverview != null)
            {
                m_FormOverview.DialogResult = DialogResult.OK;
                m_FormOverview.Close();
            }
        }

        private void axMapControl1_OnMapReplaced(object sender, IMapControlEvents2_OnMapReplacedEvent e)
        {
            /*
             * 获取地图，然后，获取书签集合
             * 如果地图有书签，遍历书签，每个书签创建一个菜单
             * 如果没书签，直接return；
             */

            //获取书签集合
            IMapBookmarks mapBookmarks =
                axMapControl1.Map as IMapBookmarks;
            IEnumSpatialBookmark bookmarks
                = mapBookmarks.Bookmarks;

            //获取当前书签
            ISpatialBookmark currentBookmark
                = bookmarks.Next();

            //如果没书签直接退出函数，有，则删除原地图文档的书签菜单，并添加一个分割条
            if (currentBookmark == null)
            {
                return;
            }
            else
            {
                Int32 bookmarksStartMenuCount = menuBookmarks.DropDownItems.Count;
                if (bookmarksStartMenuCount > 2)//有其他地图书签时
                {
                    for (int i = 2; i < bookmarksStartMenuCount; i++)
                    {
                        menuBookmarks.DropDownItems.RemoveAt(2);
                    }
                }
                //添加一个分割条
                menuBookmarks.DropDownItems.Add(new ToolStripSeparator());
            }

            //遍历书签菜单，添加菜单
            ToolStripMenuItem tempMenu = null;
            while (currentBookmark != null)
            {
                tempMenu = new ToolStripMenuItem(currentBookmark.Name);
                tempMenu.Click += new EventHandler(tempMenu_Click);
                //存储书签
                tempMenu.Tag = currentBookmark;
                menuBookmarks.DropDownItems.Add(tempMenu);

                currentBookmark = bookmarks.Next();
            }

        }

        void menuItem_Click(object sender, EventArgs e)
        {
            IAOIBookmark bookmark = (sender as ToolStripMenuItem).Tag
                as IAOIBookmark;
            bookmark.ZoomTo(axMapControl1.Map);
            axMapControl1.ActiveView.Refresh();
        }

        public void FormCreateBookmark(String bookmarkName)
        {
            //创建菜单项，其text为用户输入的文本框，但它被点击时，
            //地图就会zoom到某个位置
            IAOIBookmark mapBookmark = new AOIBookmarkClass();
            mapBookmark.Name = bookmarkName;
            mapBookmark.Location = axMapControl1.ActiveView.Extent;

            IMapBookmarks boomarks = axMapControl1.Map as IMapBookmarks;
            boomarks.AddBookmark(mapBookmark);

            ToolStripMenuItem Item = new ToolStripMenuItem(bookmarkName);
            Item.Click += new EventHandler(menuItem_Click);
            Item.Tag = mapBookmark;

            //被添加到书签菜单里面
            menuBookmarks.DropDownItems.Add(Item);
        }
     

    }
}