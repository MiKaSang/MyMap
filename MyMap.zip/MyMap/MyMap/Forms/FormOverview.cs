﻿using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Geometry;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace ElemeHntsHelper.Forms
{
    public partial class FormOverview : Form
    {
        private AxMapControl m_mapControl = null;
        public FormOverview(AxMapControl mapControl)
        {
            InitializeComponent();
            //定制地图控件，禁用鼠标与键盘对地图进行操作
            axMapControl2.AutoKeyboardScrolling = false;
            axMapControl2.AutoMouseWheel = false;
            axMapControl2.ShowScrollbars = false;
            axMapControl2.BorderStyle = esriControlsBorderStyle.esriNoBorder;
            if (mapControl!=null)
            {
               //总览窗体地图控件进行初始化
                m_mapControl = mapControl;
            }
        }

        public Boolean UpdateMapControlGraphics(IElement element)
        {
            try
            {
                IGraphicsContainer graphicsContainer = axMapControl2.Map as IGraphicsContainer;
                // 在绘制前，清除 axMapControl2 中的任何图形元素
                graphicsContainer.DeleteAllElements();
                graphicsContainer.AddElement(element, 0);

                // 刷新
                IActiveView activeView = graphicsContainer as IActiveView;
                activeView.PartialRefresh(esriViewDrawPhase.esriViewGraphics, null, null);

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void FormOverview_Load(object sender, System.EventArgs e)
        {
            if (m_mapControl!=null&&m_mapControl.LayerCount>0)
            {
                //总览窗体地图控件内容随主窗体一起变化
                axMapControl2.Map = new MapClass();
                //空间引用的赋值
                axMapControl2.SpatialReference = m_mapControl.SpatialReference;
                //添加主窗体中所有图层到总览窗体的地图控件中
                for (int i = m_mapControl.LayerCount - 1; i >= 0; i--)
                {
                    axMapControl2.AddLayer(m_mapControl.get_Layer(i));
                }
                //设置地图控件显示范围之数据的全局范围
                axMapControl2.Extent = m_mapControl.ActiveView.FullExtent;
                //刷新总览地图控件（鹰眼）中的地图
                axMapControl2.Refresh();
                //创建矩形元素
                IFillShapeElement fillShapeElement = MyMap.ElementsHelp.GetRectangleElement(m_mapControl.Extent);
                UpdateMapControlGraphics(fillShapeElement as IElement);

            }
        }

        private void FormOverview_FormClosing(object sender, FormClosingEventArgs e)
        {

            if (e.CloseReason == CloseReason.UserClosing && this.DialogResult != DialogResult.OK)
            {
                e.Cancel = true;
                this.Hide();
            }
        }

        private void axMapControl1_OnMouseDown(object sender, IMapControlEvents2_OnMouseDownEvent e)
        {
            IEnvelope envelope = null;
            if (axMapControl2.Map.LayerCount != 0 && m_mapControl != null)
            {
                // 按下鼠标左键移动矩形框
                if (e.button == 1)
                {
                    IPoint pPoint = new PointClass();
                    pPoint.PutCoords(e.mapX, e.mapY);
                    envelope = m_mapControl.Extent;
                    envelope.CenterAt(pPoint);
                }
                // 按下鼠标右键绘制矩形框
                else if (e.button == 2)
                {
                    envelope = this.axMapControl2.TrackRectangle();
                }
                m_mapControl.Extent = envelope;
                m_mapControl.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, null, null);

                axMapControl2.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, null, null);
            }
        }

         //按下鼠标左键的时候移动矩形框，同时也改变主的图控件的显示范围
        private void axMapControl2_OnMouseMove(object sender, IMapControlEvents2_OnMouseMoveEvent e)
        {
            // 如果不是左键按下就直接返回
            if (e.button != 1) return;
            IPoint pPoint = new PointClass();
            pPoint.PutCoords(e.mapX, e.mapY);

            this.m_mapControl.CenterAt(pPoint);
            this.m_mapControl.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, null, null);
            axMapControl2.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, null, null);
        }
    
    }
}
