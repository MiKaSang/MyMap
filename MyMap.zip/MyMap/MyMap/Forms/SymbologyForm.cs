﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.SystemUI;
namespace MyMap.Forms
{
    public partial class SymbologyForm : Form
    {
        private IStyleGalleryItem myGalleryItem;
        private ILegendClass myLegendClass;
        private ILayer myLayer;
        public  ISymbol mySymbol;
        public Image mySymbolImage;
        //修改构造函数，传入图例与图层接口
        public SymbologyForm(ILegendClass templeLegendClass,ILayer templeLayer)
        {
            InitializeComponent();
            this.myLegendClass = templeLegendClass;
            this.myLayer = templeLayer;
        }
        //初始化StyleClass，图层如果已有符号，则吧符号添加到符号控件的第一个符号，并选中
        private void SetFeatureClassStyle(esriSymbologyStyleClass symbologyStyleClass)
        {
            this.axSymbologyControl1.StyleClass = symbologyStyleClass;
            ISymbologyStyleClass mySymbologyStyleClass = this.axSymbologyControl1.GetStyleClass(symbologyStyleClass);
            if (this.myLegendClass!=null)
            {
                IStyleGalleryItem currentStyleGalleryItem=new  ServerStyleGalleryClass() as IStyleGalleryItem;
                currentStyleGalleryItem.Name = "当前符号";
                currentStyleGalleryItem.Item = myLegendClass.Symbol;
                mySymbologyStyleClass.AddItem(currentStyleGalleryItem, 0);
                this.myGalleryItem = currentStyleGalleryItem;
            }
            mySymbologyStyleClass.SelectItem(0);
        }
        //添加注册表读取函数，从注册表中读取ArcGIS的安装路径
        private string ReadRegistry(string sKey)
        {
            //Open the subkey for reading 

            Microsoft.Win32.RegistryKey mKey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(sKey, true);
            if (mKey==null)
            {
                return "";
            }
            return (string)mKey.GetValue("InstallDir");
        }

        private void SymbologyForm_Load(object sender, EventArgs e)
        {
            //取得安装路径
            string sInstall = ReadRegistry(@"E:\Program Files (x86)\ArcGIS\Desktop10.2\Styles\ESRI.ServerStyle");
            //载入ESRI.SeverStyle文件到符号控件
            try
            {
   
            this.axSymbologyControl1.LoadStyleFile(sInstall+@"E:\Program Files (x86)\ArcGIS\Desktop10.2\Styles\ESRI.ServerStyle");

            IGeoFeatureLayer mGeoFeatureLayer = (IGeoFeatureLayer)myLayer;
            switch (((IFeatureLayer)myLayer).FeatureClass.ShapeType)
            {
                case ESRI.ArcGIS.Geometry.esriGeometryType.esriGeometryMultiPatch:
                    this.SetFeatureClassStyle(esriSymbologyStyleClass.esriStyleClassFillSymbols);
                    this.AngleSelect.Visible = false;
                    this.SizeSelect.Visible = false;
                    this.WidthSelect.Visible = true;
                    this.BorderColor.Visible = true;
                    break;
      
                case ESRI.ArcGIS.Geometry.esriGeometryType.esriGeometryPoint:
                    this.SetFeatureClassStyle(esriSymbologyStyleClass.esriStyleClassFillSymbols);
                    this.AngleSelect.Visible = true;
                    this.SizeSelect.Visible = true;
                    this.WidthSelect.Visible = false;
                    this.BorderColor.Visible = false;
                    break;
                case ESRI.ArcGIS.Geometry.esriGeometryType.esriGeometryPolygon:
                    this.SetFeatureClassStyle(esriSymbologyStyleClass.esriStyleClassFillSymbols);
                    this.AngleSelect.Visible = false;
                    this.SizeSelect.Visible = false;
                    this.WidthSelect.Visible = true;
                    this.BorderColor.Visible = true;
                    break;
                case ESRI.ArcGIS.Geometry.esriGeometryType.esriGeometryPolyline:
                    this.SetFeatureClassStyle(esriSymbologyStyleClass.esriStyleClassFillSymbols);
                    this.AngleSelect.Visible = false;
                    this.SizeSelect.Visible = false;
                    this.WidthSelect.Visible = true;
                    this.BorderColor.Visible = false;
                    break;
                default:
                    this.Close();
                    break;
            }
              }

            catch (Exception )
            {
                MessageBox.Show("可能有点小问题，点击继续...");
            
            }

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            //取得选定的符号
            this.mySymbol = (ISymbol)myGalleryItem.Item;
            //更新预览图像
            this.mySymbolImage = this.pictureBox1.Image;

            this.Close();
        }

        private void axSymbologyControl1_OnDoubleClick(object sender, ISymbologyControlEvents_OnDoubleClickEvent e)
        {
            this.btnOK.PerformClick();
        }

        private void PreviewImage()
        {
            stdole.IPictureDisp picture = this.axSymbologyControl1.GetStyleClass(this.axSymbologyControl1.StyleClass).PreviewItem(myGalleryItem, this.pictureBox1.Width, this.pictureBox1.Height);
            System.Drawing.Image image = System.Drawing.Image.FromHbitmap(new System.IntPtr(picture.Handle));
            this.pictureBox1.Image = image;
        }

        private void axSymbologyControl1_OnStyleClassChanged(object sender, ISymbologyControlEvents_OnStyleClassChangedEvent e)
        {
            switch ((esriSymbologyStyleClass)(e.symbologyStyleClass))
            {
            
                case esriSymbologyStyleClass.esriStyleClassFillSymbols:
                    this.AngleSelect.Visible = false;
                    this.SizeSelect.Visible = false;
                    this.WidthSelect.Visible = true;
                    this.BorderColor.Visible = true;
                    break;
               
                case esriSymbologyStyleClass.esriStyleClassLineSymbols:
                    this.AngleSelect.Visible = true;
                    this.SizeSelect.Visible = true;
                    this.WidthSelect.Visible = false;
                    this.BorderColor.Visible = false;
                    break;
                
                case esriSymbologyStyleClass.esriStyleClassMarkerSymbols:
                    this.AngleSelect.Visible = false;
                    this.SizeSelect.Visible = false;
                    this.WidthSelect.Visible = true;
                    this.BorderColor.Visible = false;
                    break;    
            }

        }

        public Color ConvertIRgbColorToColor(IRgbColor pRgbColor)
        {
            return ColorTranslator.FromOle(pRgbColor.RGB);
        }

        public IColor ConvertColorToRGBColor(Color color)
        {
            IColor mColor = new RgbColorClass();
            mColor.RGB = color.B * 65536 + color.G * 256 + color.R;
            return mColor;
        }

        private void axSymbologyControl1_OnItemSelected(object sender, ISymbologyControlEvents_OnItemSelectedEvent e)
        {
            myGalleryItem = (IStyleGalleryItem)e.styleGalleryItem;
            Color color;
            switch (this.axSymbologyControl1.StyleClass)
            {

                case esriSymbologyStyleClass.esriStyleClassFillSymbols:
                    color = this.ConvertIRgbColorToColor(((IFillSymbol)myGalleryItem.Item).Color as IRgbColor);
                    this.btn_BordorColor.BackColor=this.ConvertIRgbColorToColor(((IFillSymbol)myGalleryItem.Item).Outline as IRgbColor);
                    break;

                case esriSymbologyStyleClass.esriStyleClassLineSymbols:
                    color = this.ConvertIRgbColorToColor(((ILineSymbol)myGalleryItem.Item).Color as IRgbColor);
                    this.myWidth.Value = ((decimal)((ILineSymbol)this.myGalleryItem.Item).Width);
                    break;
                //点符号
                case esriSymbologyStyleClass.esriStyleClassMarkerSymbols:
                    color = this.ConvertIRgbColorToColor(((IMarkerSymbol)myGalleryItem.Item).Color as IRgbColor);
                    this.myAngle.Value = ((decimal)((IMarkerSymbol)this.myGalleryItem.Item).Angle);
                    this.mySize.Value = ((decimal)((IMarkerSymbol)this.myGalleryItem.Item).Size);
                    break;
                default:
                    color = Color.Black;
                    break;
            }
            this.btn_Color.BackColor = color;
            this.PreviewImage();
        }

        private void mySize_ValueChanged(object sender, EventArgs e)
        {
            ((IMarkerSymbol)this.myGalleryItem).Size = (double)this.mySize.Value;
            this.PreviewImage();
        }

        private void myWidth_ValueChanged(object sender, EventArgs e)
        {
            switch (this.axSymbologyControl1.StyleClass)
            {
           
                case esriSymbologyStyleClass.esriStyleClassFillSymbols:
                    ILineSymbol mLineSymbol = ((IFillSymbol)this.myGalleryItem.Item).Outline;
                    mLineSymbol.Width = Convert.ToDouble(this.myWidth.Value);
                    ((IFillSymbol)this.myGalleryItem.Item).Outline = mLineSymbol;
                    break;
                case esriSymbologyStyleClass.esriStyleClassLineSymbols:
                    ((ILineSymbol)this.myGalleryItem.Item).Width = Convert.ToDouble(this.myWidth.Value);
                    break;
              
                default:
                    break;
            }
            this.PreviewImage();
        }

        private void myAngle_ValueChanged(object sender, EventArgs e)
        {
            ((IMarkerSymbol)this.myGalleryItem).Angle = (double)this.mySize.Value;
            this.PreviewImage();
        }

        private void btn_Color_Click(object sender, EventArgs e)
        {
            //调用系统颜色对话框
           
        }


       
    }
}
