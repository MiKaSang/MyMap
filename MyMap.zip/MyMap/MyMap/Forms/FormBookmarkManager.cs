﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MyMap.Forms
{
    public partial class FormBookmarkManager : Form
    {
        private AxMapControl m_AxMapControl = null;
        private IEnumSpatialBookmark m_BookMarks = null;
        public FormBookmarkManager(AxMapControl axMapControl)
        {
            InitializeComponent();
            m_AxMapControl = axMapControl;
            if (m_AxMapControl != null)
            {
                IMapBookmarks mapBookmarksWrapper = m_AxMapControl.Map as IMapBookmarks;
                m_BookMarks = mapBookmarksWrapper.Bookmarks;
            }
        }

        private void FormBookmarkManager_Load(object sender, System.EventArgs e)
        {
            ISpatialBookmark currentBookmark = m_BookMarks.Next();

            while (currentBookmark != null)
            {
                //生成一个listviewitem,并且添加到listview1
                ListViewItem lvi = new ListViewItem();
                lvi.Text = currentBookmark.Name;
                listView1.Items.Add(lvi);

                currentBookmark = m_BookMarks.Next();
            }
        }

        private void btnZoomTo_Click(object sender, System.EventArgs e)
        {
            m_BookMarks.Reset();//书签指针归零
            ISpatialBookmark theBookmark = m_BookMarks.Next();
            while (theBookmark != null)
            {
                if (theBookmark.Name == listView1.SelectedItems[0].Text)
                {
                    //调用zoomto
                    theBookmark.ZoomTo(m_AxMapControl.Map);
                    m_AxMapControl.ActiveView.Refresh();
                }
                theBookmark = m_BookMarks.Next();
            }
        }


    }
}
