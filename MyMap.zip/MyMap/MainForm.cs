﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.ADF;
using ESRI.ArcGIS.SystemUI;
using MyMap.Forms;
using ElemeHntsHelper.Forms;
using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.Geodatabase;
using MyMap;
using MyMap.Commands;
using Myap.Commands;
namespace ElementsHelper
{
    public sealed partial class MainForm : Form
    {
        #region class private members
        private IMapControlDefault m_mapControl = null;
        private string m_mapDocumentName = string.Empty;
        private FormOverview m_FormOverview = null;
        private int mQueryMode;     //空间查询的查询方式
        private int mLayerIndex;        //图层索引
        private ITOCControlDefault m_tocControl;//控件变量
        private IToolbarMenu m_menuMap;//tocControl中的Map菜单
        private ToolbarMenu m_menuLayer;//tocControl中的图层菜单
        private IPageLayoutControlDefault m_pageLayoutControl = null;
        private ControlsSynchronizer m_controlsSynchronizer = null;
        private string sMapUnits;
        #endregion

        #region class constructor
        public MainForm()
        {
            InitializeComponent();
            try
            {
                //初始化IMapControlDefault与IPageLayoutControlDefault接口变量
                m_mapControl = axMapControl1.Object as IMapControlDefault;
                m_pageLayoutControl = axPageLayoutControl1.Object as IPageLayoutControlDefault;
                m_tocControl = axTOCControl1.Object as ITOCControlDefault;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion

        #region Main Menu event handlers
        private void menuNewDoc_Click(object sender, EventArgs e)
        {
            //execute New Document command
            ICommand command = new CreateNewDocument();
            command.OnCreate(m_mapControl.Object);
            command.OnClick();
        }

        private void menuOpenDoc_Click(object sender, EventArgs e)
        {
            //execute Open Document command
            ICommand command = new ControlsOpenDocCommandClass();
            command.OnCreate(m_mapControl.Object);
            command.OnClick();
        }

        private void menuSaveDoc_Click(object sender, EventArgs e)
        {
            //execute Save Document command
            if (m_mapControl.CheckMxFile(m_mapDocumentName))
            {
                //create a new instance of a MapDocument
                IMapDocument mapDoc = new MapDocumentClass();
                mapDoc.Open(m_mapDocumentName, string.Empty);

                //Make sure that the MapDocument is not readonly
                if (mapDoc.get_IsReadOnly(m_mapDocumentName))
                {
                    MessageBox.Show("地图文件不可写！");
                    mapDoc.Close();
                    return;
                }

                //Replace its contents with the current map
                mapDoc.ReplaceContents((IMxdContents)m_mapControl.Map);

                //save the MapDocument in order to persist it
                mapDoc.Save(mapDoc.UsesRelativePaths, false);

                //close the MapDocument
                mapDoc.Close();
            }
        }

        private void menuSaveAs_Click(object sender, EventArgs e)
        {
            //execute SaveAs Document command
            ICommand command = new ControlsSaveAsDocCommandClass();
            command.OnCreate(m_mapControl.Object);
            command.OnClick();
        }

        private void menuExitApp_Click(object sender, EventArgs e)
        {
            //exit the application
            Application.Exit();
        }
        #endregion

        //listen to MapReplaced evant in order to update the statusbar and the Save menu
        //private void axMapControl1_OnMapReplaced(object sender, IMapControlEvents2_OnMapReplacedEvent e)
        //{
        //    //get the current document name from the MapControl
        //    m_mapDocumentName = m_mapControl.DocumentFilename;

        //    //if there is no MapDocument, diable the Save menu and clear the statusbar
        //    if (m_mapDocumentName == string.Empty)
        //    {
        //        menuSaveDoc.Enabled = false;
        //        statusBarXY.Text = string.Empty;
        //    }
        //    else
        //    {
        //        //enable the Save manu and write the doc name to the statusbar
        //        menuSaveDoc.Enabled = true;
        //        statusBarXY.Text = Path.GetFileName(m_mapDocumentName);
        //    }
        //}

        private void MainForm_Load(object sender, EventArgs e)
        {
            //状态栏坐标系
            sMapUnits = "Unknown";
            //get the MapControl
            m_mapControl = (IMapControlDefault)axMapControl1.Object;

            //disable the Save menu (since there is no document yet)
            menuSaveDoc.Enabled = false;
            m_menuMap = new ToolbarMenuClass();
            m_menuLayer = new ToolbarMenuClass();

            m_controlsSynchronizer = new ControlsSynchronizer(m_mapControl, m_pageLayoutControl);
            //把 MapControl 和 PageLayoutControl 绑定起来(两个都指向同一个 Map),然后设置 MapControl 为活动的 Control
            m_controlsSynchronizer.BindControls(true);
            //为了在切换 MapControl 和 PageLayoutControl 视图同步，要添加 Framework Control
            m_controlsSynchronizer.AddFrameworkControl(axToolbarControl1.Object);
            m_controlsSynchronizer.AddFrameworkControl(axTOCControl1.Object);
            m_menuMap.AddItem(new OpenNewMapDocument(m_controlsSynchronizer), -1, 0, false, esriCommandStyles.esriCommandStyleIconAndText);
            //打开全部图层菜单
            m_menuMap.AddItem(new LayerVisibility(), 1, -1, true, esriCommandStyles.esriCommandStyleTextOnly);
            //关闭全部图层菜单
            m_menuMap.AddItem(new LayerVisibility(), 2, -1, false, esriCommandStyles.esriCommandStyleTextOnly);
            m_menuMap.SetHook(m_mapControl);

            //添加“移除图层”菜单项
            m_menuLayer.AddItem(new RemoveLayer(), -1, 0, false, esriCommandStyles.esriCommandStyleTextOnly);
            //添加“放大到整个图层”菜单项
            m_menuLayer.AddItem(new ZoomToLayer(), -1, 1, true, esriCommandStyles.esriCommandStyleTextOnly);
            //设置菜单的 Hook
            m_menuLayer.SetHook(m_mapControl);

            //添加打开命令按钮到工具条
            OpenNewMapDocument openMapDoc = new OpenNewMapDocument(m_controlsSynchronizer);
            axToolbarControl1.AddItem(openMapDoc, -1, 0, false, -1, esriCommandStyles.esriCommandStyleIconOnly);
        }
        private void New_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("是否保存当前地图?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                //如果要保存，调用另存为对话框
                ICommand command = new ControlsSaveAsDocCommandClass();
                if (m_mapControl != null)
                {
                    command.OnCreate(m_controlsSynchronizer.MapControl.Object);
                }
                else
                {
                    command.OnCreate(m_controlsSynchronizer.PageLayoutControl.Object);
                    command.OnClick();
                }
            }
            //创建新的地图实例
            IMap map = new MapClass();
            map.Name = "Map";
            m_controlsSynchronizer.MapControl.DocumentFilename = string.Empty;
            //更新新建地图实例的共享地图文档
            m_controlsSynchronizer.ReplaceMap(map);
        }

        private void Open_Click(object sender, EventArgs e)
        {
            if (this.axMapControl1.LayerCount > 0)
            {
                DialogResult result = MessageBox.Show("是否保存当前地图？", "警告", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (result == DialogResult.Cancel) return;
                if (result == DialogResult.Yes) this.menuSaveDoc_Click(null, null);
            }
            OpenNewMapDocument openMapDoc = new OpenNewMapDocument(m_controlsSynchronizer);
            openMapDoc.OnCreate(m_controlsSynchronizer.MapControl.Object);
            openMapDoc.OnClick();
         }

        private void axMapControl1_OnMouseMove(object sender, IMapControlEvents2_OnMouseMoveEvent e)
        {
            // 显示当前比例尺,整数
            toolStripStatusScale.Text = " 比例尺 1:" + ((long)this.axMapControl1.MapScale).ToString();

            // 显示当前坐标，保留小数点后四位
            toolStripStatusCoordinates.Text = " 当前坐标 X = " + e.mapX.ToString() + " Y = " + e.mapY.ToString() + " " + this.axMapControl1.MapUnits;
        }

        private void MenuItemOverview_Click(object sender, EventArgs e)
        {
            
            try
            {
                if (m_FormOverview == null || m_FormOverview.IsDisposed)
                {
                    m_FormOverview = new FormOverview(axMapControl1);
                }
                m_FormOverview.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void axTOCControl1_OnDoubleClick(object sender, ITOCControlEvents_OnDoubleClickEvent e)
        {
            esriTOCControlItem itemType  = esriTOCControlItem.esriTOCControlItemNone;
            IBasicMap basicMap = null;
            ILayer layer = null;
            object unk = null;
            object data = null;
            axTOCControl1.HitTest(e.x, e.y, ref itemType, ref basicMap, ref layer, ref unk, ref data);
            if (e.button==1)
            {
                //System.Drawing.Point pos = new System.Drawing.Point(e.x,e.y);
                if (itemType==esriTOCControlItem.esriTOCControlItemLegendClass)
                {
                    //取到图例
                    ILegendClass m_LengendClass = ((ILegendGroup)unk).get_Class((int)data);
                    //创建符号选择器实例
                    MyMap.Forms.SymbologyForm symbologyform= new MyMap.Forms.SymbologyForm(m_LengendClass,layer);
                    if (symbologyform.ShowDialog()==DialogResult.OK)
                    {
                        //refresh axMapControl1
                        m_mapControl.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, null, null);
                        //set the new symbology
                        m_LengendClass.Symbol = symbologyform.mySymbol;
                        //refresh axMapControl and TOCControl
                        this.axMapControl1.ActiveView.Refresh();
                        this.axTOCControl1.Refresh();
                    }
                }
            }
        }

        private void ToolStripMenuItemBookmarkManager_Click(object sender, EventArgs e)
        {
            FormBookmarkManager frm = new FormBookmarkManager(axMapControl1);
            frm.Show();
        }

        private void ToolStripMenuItemCreateBookmark_Click(object sender, EventArgs e)
        {
            FormCreateBookmark frm = new FormCreateBookmark(this);
            frm.ShowDialog();
        }

        void tempMenu_Click(object sender, EventArgs e)
        {
            ISpatialBookmark bookmark
                = (sender as ToolStripMenuItem).Tag as ISpatialBookmark;
            if (bookmark != null)
            {
                bookmark.ZoomTo(axMapControl1.Map);
                //刷新地图
                //axMapControl1.ActiveView.Refresh();
                axMapControl1.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewAll, null, axMapControl1.ActiveView.Extent);
            }
        }

        private void CloseOverviewForm()
        {
            if (m_FormOverview != null)
            {
                m_FormOverview.DialogResult = DialogResult.OK;
                m_FormOverview.Close();
            }
        }

        private void axMapControl1_OnMapReplaced(object sender, IMapControlEvents2_OnMapReplacedEvent e)
        {
            /*
             * 获取地图，然后，获取书签集合
             * 如果地图有书签，遍历书签，每个书签创建一个菜单
             * 如果没书签，直接return；
             */

            //获取书签集合
            IMapBookmarks mapBookmarks =
                axMapControl1.Map as IMapBookmarks;
            IEnumSpatialBookmark bookmarks
                = mapBookmarks.Bookmarks;

            //获取当前书签
            ISpatialBookmark currentBookmark
                = bookmarks.Next();

            //如果没书签直接退出函数，有，则删除原地图文档的书签菜单，并添加一个分割条
            if (currentBookmark == null)
            {
                return;
            }
            else
            {
                Int32 bookmarksStartMenuCount = menuBookmarks.DropDownItems.Count;
                if (bookmarksStartMenuCount > 2)//有其他地图书签时
                {
                    for (int i = 2; i < bookmarksStartMenuCount; i++)
                    {
                        menuBookmarks.DropDownItems.RemoveAt(2);
                    }
                }
                //添加一个分割条
                menuBookmarks.DropDownItems.Add(new ToolStripSeparator());
            }

            //遍历书签菜单，添加菜单
            ToolStripMenuItem tempMenu = null;
            while (currentBookmark != null)
            {
                tempMenu = new ToolStripMenuItem(currentBookmark.Name);
                tempMenu.Click += new EventHandler(tempMenu_Click);
                //存储书签
                tempMenu.Tag = currentBookmark;
                menuBookmarks.DropDownItems.Add(tempMenu);

                currentBookmark = bookmarks.Next();
            }
            esriUnits mapUnits = axMapControl1.MapUnits;
            switch (mapUnits)
            {
                case esriUnits.esriCentimeters:
                    sMapUnits = "Centimeters";
                    break;
                case esriUnits.esriDecimalDegrees:
                    sMapUnits = "Decimal Degrees";
                    break;
                case esriUnits.esriDecimeters:
                    sMapUnits = "Decimeters";
                    break;
                case esriUnits.esriFeet:
                    sMapUnits = "Feet";
                    break;
                case esriUnits.esriKilometers:
                    sMapUnits = "Kilometers";
                    break;
                case esriUnits.esriMeters:
                    sMapUnits = "Meters";
                    break;
                case esriUnits.esriMiles:
                    sMapUnits = "Miles";
                    break;
                case esriUnits.esriMillimeters:
                    sMapUnits = "Millimeters";
                    break;
                case esriUnits.esriNauticalMiles:
                    sMapUnits = "NauticalMiles";
                    break;
                case esriUnits.esriPoints:
                    sMapUnits = "Points";
                    break;
                case esriUnits.esriUnknownUnits:
                    sMapUnits = "Unknown";
                    break;
                case esriUnits.esriYards:
                    sMapUnits = "Yards";
                    break;
            }
        }

        void menuItem_Click(object sender, EventArgs e)
        {
            IAOIBookmark bookmark = (sender as ToolStripMenuItem).Tag
                as IAOIBookmark;
            bookmark.ZoomTo(axMapControl1.Map);
            axMapControl1.ActiveView.Refresh();
        }

        public void FormCreateBookmark(String bookmarkName)
        {
            //创建菜单项，其text为用户输入的文本框，但它被点击时，
            //地图就会zoom到某个位置
            IAOIBookmark mapBookmark = new AOIBookmarkClass();
            mapBookmark.Name = bookmarkName;
            mapBookmark.Location = axMapControl1.ActiveView.Extent;

            IMapBookmarks boomarks = axMapControl1.Map as IMapBookmarks;
            boomarks.AddBookmark(mapBookmark);

            ToolStripMenuItem Item = new ToolStripMenuItem(bookmarkName);
            Item.Click += new EventHandler(menuItem_Click);
            Item.Tag = mapBookmark;

            //被添加到书签菜单里面
            menuBookmarks.DropDownItems.Add(Item);
        }

        private void MenuItemAttributeQuery_Click(object sender, EventArgs e)
        {
            AttributeQueryForm attributequery= new AttributeQueryForm(axMapControl1);
            attributequery.Show();
        }

        private void MenuItemSpatialQuery_Click(object sender, EventArgs e)
        {
            //初始化空间查询窗体
            SpatialQueryForm spatialQueryForm = new SpatialQueryForm(this.axMapControl1);
            if (spatialQueryForm.ShowDialog() == DialogResult.OK)
            {
                //标记为“空间查询”
                //this.mTool = "SpaceQuery";
                //获取查询方式和图层
                this.mQueryMode = spatialQueryForm.mQueryMode;
                this.mLayerIndex = spatialQueryForm.mLayerIndex;
                //定义鼠标形状
                this.axMapControl1.MousePointer = ESRI.ArcGIS.Controls.esriControlsMousePointer.esriPointerCrosshair;
            }


        }

        private DataTable LoadQueryResult(AxMapControl mapControl, IFeatureLayer featureLayer, IGeometry geometry)
        {
            IFeatureClass pFeatureClass = featureLayer.FeatureClass;
            //根据图层属性字段初始化DataTable
            IFields pFields = pFeatureClass.Fields;
            DataTable pDataTable = new DataTable();
            for (int i = 0; i < pFields.FieldCount; i++)
            {
                string strFldName;
                strFldName = pFields.get_Field(i).AliasName;
                pDataTable.Columns.Add(strFldName);
            }
            //空间过滤器
            ISpatialFilter pSpatialFilter = new SpatialFilterClass();
            pSpatialFilter.Geometry = geometry;
            //根据图层类型选择缓冲方式
            switch (pFeatureClass.ShapeType)
            {
                case esriGeometryType.esriGeometryPoint:
                    pSpatialFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelContains;
                    break;
                case esriGeometryType.esriGeometryPolyline:
                    pSpatialFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelCrosses;
                    break;
                case esriGeometryType.esriGeometryPolygon:
                    pSpatialFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelIntersects;
                    break;
            }
            //定义空间过滤器的空间字段
            pSpatialFilter.GeometryField = pFeatureClass.ShapeFieldName;
            IQueryFilter pQueryFilter;
            IFeatureCursor pFeatureCursor;
            IFeature pFeature;
            //利用要素过滤器查询要素
            pQueryFilter = pSpatialFilter as IQueryFilter;
            pFeatureCursor = featureLayer.Search(pQueryFilter, true);
            pFeature = pFeatureCursor.NextFeature();
            while (pFeature != null)
            {
                string strFldValue = null;
                DataRow dr = pDataTable.NewRow();
                //遍历图层属性表字段值，并加入pDataTable
                for (int i = 0; i < pFields.FieldCount; i++)
                {
                    string strFldName = pFields.get_Field(i).Name;
                    if (strFldName == "Shape")
                    {
                        strFldValue = Convert.ToString(pFeature.Shape.GeometryType);
                    }
                    else
                        strFldValue = Convert.ToString(pFeature.get_Value(i));
                    dr[i] = strFldValue;
                }
                pDataTable.Rows.Add(dr);
                //高亮选择要素
                mapControl.Map.SelectFeature((ILayer)featureLayer, pFeature);
                mapControl.ActiveView.Refresh();
                pFeature = pFeatureCursor.NextFeature();
            }
            return pDataTable;
        }

        private void axMapControl1_OnMouseDown(object sender, IMapControlEvents2_OnMouseDownEvent e)
        {
            #region  空间查询
            this.axMapControl1.Map.ClearSelection();
            //获取当前视图
            IActiveView pActiveView = this.axMapControl1.ActiveView;
            //获取鼠标点
            IPoint pPoint = pActiveView.ScreenDisplay.DisplayTransformation.ToMapPoint(e.x, e.y);

            panel1.Visible = true;
            IGeometry pGeometry = null;
            if (this.mQueryMode == 0)//矩形查询
            {
                pGeometry = this.axMapControl1.TrackRectangle();
            }
            else if (this.mQueryMode == 1)//线查询
            {
                pGeometry = this.axMapControl1.TrackLine();
            }
            else if (this.mQueryMode == 2)//点查询
            {
                ITopologicalOperator pTopo;
                IGeometry pBuffer;
                pGeometry = pPoint;
                pTopo = pGeometry as ITopologicalOperator;
                //根据点位创建缓冲区，缓冲半径为0.1，可修改
                pBuffer = pTopo.Buffer(0.1);
                pGeometry = pBuffer.Envelope;
            }
            else if (this.mQueryMode == 3)//圆查询
            {
                pGeometry = this.axMapControl1.TrackCircle();
            }
            IFeatureLayer pFeatureLayer = this.axMapControl1.get_Layer(this.mLayerIndex) as IFeatureLayer;
            DataTable pDataTable = this.LoadQueryResult(this.axMapControl1, pFeatureLayer, pGeometry);
            this.dataGridView1.DataSource = pDataTable.DefaultView;
            this.dataGridView1.Refresh();
            #endregion

            if (e.button == 2)
            {
                //弹出右键菜单
                m_menuMap.PopupMenu(e.x, e.y, m_mapControl.hWnd);
            }
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void axTOCControl1_OnMouseDown(object sender, ITOCControlEvents_OnMouseDownEvent e)
        {
            //如果不是右键按下直接返回
            if (e.button != 2) return;

            esriTOCControlItem itemType = esriTOCControlItem.esriTOCControlItemNone;
            IBasicMap basicMap = null;
            ILayer layer = null;
            object other = null;
            object data = null;

            //判断所选菜单的类型
            m_tocControl.HitTest(e.x, e.y, ref itemType, ref basicMap, ref layer, ref other, ref data);

            //确定选定的菜单类型， Map 或是图层菜单
            if (itemType == esriTOCControlItem.esriTOCControlItemMap)
                m_tocControl.SelectItem(basicMap, null);
            else
                m_tocControl.SelectItem(layer, null);
            //设置 CustomProperty 为 layer ( 用于自定义的 Layer 命令)
            m_mapControl.CustomProperty = layer;
            //弹出右键菜单
            if (itemType == esriTOCControlItem.esriTOCControlItemMap)
                m_menuMap.PopupMenu(e.x, e.y, m_tocControl.hWnd);
            if (itemType == esriTOCControlItem.esriTOCControlItemLayer)
                m_menuLayer.PopupMenu(e.x, e.y, m_tocControl.hWnd);
        }

        private void axToolbarControl1_OnMouseMove(object sender, IToolbarControlEvents_OnMouseMoveEvent e)
        {

            // 取得鼠标所在工具的索引号
            int index = axToolbarControl1.HitTest(e.x, e.y, false);
            if (index != -1)
            {
                // 取得鼠标所在工具的 ToolbarItem
                IToolbarItem toolbarItem = axToolbarControl1.GetItem(index);
                // 设置状态栏信息
                toolStripStatusMessage.Text = toolbarItem.Command.Message;
            }
            else
            {
                toolStripStatusMessage.Text = " 就绪 ";
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 0) //map view
            {
                //activate the MapControl and deactivate the PageLayoutControl
                m_controlsSynchronizer.ActivateMap();
            }
            else //layout view
            {
                //activate the PageLayoutControl and deactivate the MapControl
                m_controlsSynchronizer.ActivatePageLayout();
            }
        }


 



    }
}