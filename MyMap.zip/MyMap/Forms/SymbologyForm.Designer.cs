﻿namespace MyMap.Forms
{
    partial class SymbologyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SymbologyForm));
            this.axSymbologyControl1 = new ESRI.ArcGIS.Controls.AxSymbologyControl();
            this.Preview = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Setmenu = new System.Windows.Forms.GroupBox();
            this.btn_BordorColor = new System.Windows.Forms.Button();
            this.btn_Color = new System.Windows.Forms.Button();
            this.BorderColor = new System.Windows.Forms.Label();
            this.AngleSelect = new System.Windows.Forms.Label();
            this.WidthSelect = new System.Windows.Forms.Label();
            this.SizeSelect = new System.Windows.Forms.Label();
            this.ColorSelect = new System.Windows.Forms.Label();
            this.myAngle = new System.Windows.Forms.NumericUpDown();
            this.myWidth = new System.Windows.Forms.NumericUpDown();
            this.mySize = new System.Windows.Forms.NumericUpDown();
            this.More = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.contextMenuStripMoreSymbology = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.axSymbologyControl1)).BeginInit();
            this.Preview.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Setmenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.myAngle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mySize)).BeginInit();
            this.SuspendLayout();
            // 
            // axSymbologyControl1
            // 
            this.axSymbologyControl1.Location = new System.Drawing.Point(1, -1);
            this.axSymbologyControl1.Name = "axSymbologyControl1";
            this.axSymbologyControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axSymbologyControl1.OcxState")));
            this.axSymbologyControl1.Size = new System.Drawing.Size(238, 373);
            this.axSymbologyControl1.TabIndex = 0;
            this.axSymbologyControl1.OnDoubleClick += new ESRI.ArcGIS.Controls.ISymbologyControlEvents_Ax_OnDoubleClickEventHandler(this.axSymbologyControl1_OnDoubleClick);
            this.axSymbologyControl1.OnStyleClassChanged += new ESRI.ArcGIS.Controls.ISymbologyControlEvents_Ax_OnStyleClassChangedEventHandler(this.axSymbologyControl1_OnStyleClassChanged);
            this.axSymbologyControl1.OnItemSelected += new ESRI.ArcGIS.Controls.ISymbologyControlEvents_Ax_OnItemSelectedEventHandler(this.axSymbologyControl1_OnItemSelected);
            // 
            // Preview
            // 
            this.Preview.Controls.Add(this.pictureBox1);
            this.Preview.Location = new System.Drawing.Point(256, 12);
            this.Preview.Name = "Preview";
            this.Preview.Size = new System.Drawing.Size(125, 100);
            this.Preview.TabIndex = 1;
            this.Preview.TabStop = false;
            this.Preview.Text = "预览";
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(9, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(107, 80);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Setmenu
            // 
            this.Setmenu.Controls.Add(this.btn_BordorColor);
            this.Setmenu.Controls.Add(this.btn_Color);
            this.Setmenu.Controls.Add(this.BorderColor);
            this.Setmenu.Controls.Add(this.AngleSelect);
            this.Setmenu.Controls.Add(this.WidthSelect);
            this.Setmenu.Controls.Add(this.SizeSelect);
            this.Setmenu.Controls.Add(this.ColorSelect);
            this.Setmenu.Controls.Add(this.myAngle);
            this.Setmenu.Controls.Add(this.myWidth);
            this.Setmenu.Controls.Add(this.mySize);
            this.Setmenu.Location = new System.Drawing.Point(256, 118);
            this.Setmenu.Name = "Setmenu";
            this.Setmenu.Size = new System.Drawing.Size(135, 162);
            this.Setmenu.TabIndex = 2;
            this.Setmenu.TabStop = false;
            this.Setmenu.Text = "设置";
            // 
            // btn_BordorColor
            // 
            this.btn_BordorColor.Location = new System.Drawing.Point(58, 130);
            this.btn_BordorColor.Name = "btn_BordorColor";
            this.btn_BordorColor.Size = new System.Drawing.Size(54, 23);
            this.btn_BordorColor.TabIndex = 9;
            this.btn_BordorColor.UseVisualStyleBackColor = true;
            this.btn_BordorColor.Click += new System.EventHandler(this.btn_BordorColor_Click);
            // 
            // btn_Color
            // 
            this.btn_Color.Location = new System.Drawing.Point(54, 15);
            this.btn_Color.Name = "btn_Color";
            this.btn_Color.Size = new System.Drawing.Size(58, 23);
            this.btn_Color.TabIndex = 8;
            this.btn_Color.UseVisualStyleBackColor = true;
            this.btn_Color.Click += new System.EventHandler(this.btn_Color_Click);
            // 
            // BorderColor
            // 
            this.BorderColor.AutoSize = true;
            this.BorderColor.Location = new System.Drawing.Point(1, 135);
            this.BorderColor.Name = "BorderColor";
            this.BorderColor.Size = new System.Drawing.Size(53, 12);
            this.BorderColor.TabIndex = 7;
            this.BorderColor.Text = "边框颜色";
            // 
            // AngleSelect
            // 
            this.AngleSelect.AutoSize = true;
            this.AngleSelect.Location = new System.Drawing.Point(9, 103);
            this.AngleSelect.Name = "AngleSelect";
            this.AngleSelect.Size = new System.Drawing.Size(29, 12);
            this.AngleSelect.TabIndex = 6;
            this.AngleSelect.Text = "角度";
            // 
            // WidthSelect
            // 
            this.WidthSelect.AutoSize = true;
            this.WidthSelect.Location = new System.Drawing.Point(9, 77);
            this.WidthSelect.Name = "WidthSelect";
            this.WidthSelect.Size = new System.Drawing.Size(29, 12);
            this.WidthSelect.TabIndex = 5;
            this.WidthSelect.Text = "宽度";
            // 
            // SizeSelect
            // 
            this.SizeSelect.AutoSize = true;
            this.SizeSelect.Location = new System.Drawing.Point(9, 48);
            this.SizeSelect.Name = "SizeSelect";
            this.SizeSelect.Size = new System.Drawing.Size(29, 12);
            this.SizeSelect.TabIndex = 4;
            this.SizeSelect.Text = "大小";
            // 
            // ColorSelect
            // 
            this.ColorSelect.AutoSize = true;
            this.ColorSelect.Location = new System.Drawing.Point(9, 22);
            this.ColorSelect.Name = "ColorSelect";
            this.ColorSelect.Size = new System.Drawing.Size(29, 12);
            this.ColorSelect.TabIndex = 3;
            this.ColorSelect.Text = "颜色";
            // 
            // myAngle
            // 
            this.myAngle.Location = new System.Drawing.Point(49, 101);
            this.myAngle.Name = "myAngle";
            this.myAngle.Size = new System.Drawing.Size(81, 21);
            this.myAngle.TabIndex = 2;
            this.myAngle.ValueChanged += new System.EventHandler(this.myAngle_ValueChanged);
            // 
            // myWidth
            // 
            this.myWidth.Location = new System.Drawing.Point(51, 71);
            this.myWidth.Name = "myWidth";
            this.myWidth.Size = new System.Drawing.Size(81, 21);
            this.myWidth.TabIndex = 1;
            this.myWidth.ValueChanged += new System.EventHandler(this.myWidth_ValueChanged);
            // 
            // mySize
            // 
            this.mySize.Location = new System.Drawing.Point(52, 44);
            this.mySize.Name = "mySize";
            this.mySize.Size = new System.Drawing.Size(81, 21);
            this.mySize.TabIndex = 0;
            this.mySize.ValueChanged += new System.EventHandler(this.mySize_ValueChanged);
            // 
            // More
            // 
            this.More.Location = new System.Drawing.Point(305, 286);
            this.More.Name = "More";
            this.More.Size = new System.Drawing.Size(75, 24);
            this.More.TabIndex = 3;
            this.More.Text = "更多符号";
            this.More.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(306, 317);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 4;
            this.btnOK.Text = "确认";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(306, 346);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "取消";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "Styles文件|*.SeverStyle";
            // 
            // contextMenuStripMoreSymbology
            // 
            this.contextMenuStripMoreSymbology.Name = "contextMenuStripMoreSymbology";
            this.contextMenuStripMoreSymbology.Size = new System.Drawing.Size(61, 4);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(153, 26);
            // 
            // SymbologyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(393, 384);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.More);
            this.Controls.Add(this.Setmenu);
            this.Controls.Add(this.Preview);
            this.Controls.Add(this.axSymbologyControl1);
            this.Name = "SymbologyForm";
            this.Text = "选择符号";
            this.Load += new System.EventHandler(this.SymbologyForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.axSymbologyControl1)).EndInit();
            this.Preview.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Setmenu.ResumeLayout(false);
            this.Setmenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.myAngle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mySize)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ESRI.ArcGIS.Controls.AxSymbologyControl axSymbologyControl1;
        private System.Windows.Forms.GroupBox Preview;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox Setmenu;
        private System.Windows.Forms.Label BorderColor;
        private System.Windows.Forms.Label AngleSelect;
        private System.Windows.Forms.Label WidthSelect;
        private System.Windows.Forms.Label SizeSelect;
        private System.Windows.Forms.Label ColorSelect;
        private System.Windows.Forms.NumericUpDown myAngle;
        private System.Windows.Forms.NumericUpDown myWidth;
        private System.Windows.Forms.NumericUpDown mySize;
        private System.Windows.Forms.Button More;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btn_BordorColor;
        private System.Windows.Forms.Button btn_Color;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripMoreSymbology;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;

    }
}