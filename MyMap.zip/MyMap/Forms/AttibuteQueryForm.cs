﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.SystemUI;
using ESRI.ArcGIS.DisplayUI;

namespace MyMap.Forms
{
    public partial class AttributeQueryForm : Form
    {
        private AxMapControl mMapControl;
        private IFeatureLayer mFeatureLayer;
        public AttributeQueryForm(AxMapControl mapControl)
        {
            InitializeComponent();
            this.mMapControl = mapControl;
        }

        private void AttibuteQueryForm_Load(object sender, EventArgs e)
        {
            //MapControl中没有图层时返回
            if (this.mMapControl.LayerCount <= 0)
                return;
            //获取MapControl中的全部图层名称，并加入ComboBox
            //图层
            ILayer pLayer;
            //图层名称
            string strLayerName;
            for (int i = 0; i < this.mMapControl.LayerCount; i++)
            {
                pLayer = this.mMapControl.get_Layer(i);
                strLayerName = pLayer.Name;
                //图层名称加入cboLayer
                this.cboLayer.Items.Add(strLayerName);
            }
            //默认显示第一个选项
            this.cboLayer.SelectedIndex = 0;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            //定义图层，要素游标，查询过滤器，要素
            IFeatureCursor pFeatureCursor;
            IQueryFilter pQueryFilter;
            IFeature pFeature;
            IPoint pPoint;
            IEnvelope pEnv;
            pEnv = mMapControl.ActiveView.Extent;
            pPoint = new PointClass();
            pPoint.X = pEnv.XMin + pEnv.Width / 2;
            pPoint.Y = pEnv.YMin + pEnv.Height / 2;
            if (this.mMapControl.LayerCount <= 0)
                return;
            //获取图层
            mFeatureLayer = mMapControl.get_Layer(cboLayer.SelectedIndex) as IFeatureLayer;
            //清除上次查询结果
            this.mMapControl.Map.ClearSelection();
            this.mMapControl.ActiveView.Refresh();
            //pQueryFilter的实例化
            pQueryFilter = new QueryFilterClass();
            //设置查询过滤条件
            pQueryFilter.WhereClause = cboField.Text + "=" + txtValue.Text;
            //查询
            pFeatureCursor = mFeatureLayer.Search(pQueryFilter, true);
            //获取查询到的要素
            pFeature = pFeatureCursor.NextFeature();
            //判断是否获取到要素
            if (pFeature != null)
            {
                //选择要素
                this.mMapControl.Map.SelectFeature(mFeatureLayer, pFeature);
                //放大到要素
                pFeature.Shape.Envelope.CenterAt(pPoint);
                this.mMapControl.Extent = pFeature.Shape.Envelope;
            }
            else
            {
                //没有得到pFeature的提示
                MessageBox.Show("没有找到相关要素！", "提示");

            }

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void cboLayer_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            //获取cboLayer中选中的图层
            mFeatureLayer = mMapControl.get_Layer(cboLayer.SelectedIndex) as IFeatureLayer;
            IFeatureClass pFeatureClass = mFeatureLayer.FeatureClass;
            //字段名称
            string strFldName;
            for (int i = 0; i < pFeatureClass.Fields.FieldCount; i++)
            {
                strFldName = pFeatureClass.Fields.get_Field(i).Name;
                //图层名称加入cboField
                this.cboField.Items.Add(strFldName);
            }
            //默认显示第一个选项
            this.cboField.SelectedIndex = 0;
        }

    }
}
